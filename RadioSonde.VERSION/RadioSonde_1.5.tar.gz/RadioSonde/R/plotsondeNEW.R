skewtPlot <- 
  function (sondeData, 
             winds = FALSE, windplot = c(.85,.95,.1,.9), 
            skewplot= c( .2, .8, .15, .9),
            s = 3., col = c("black", "red"),
            mar.skewt = c(5.1, 5.1 ,
                          2.1 , 3.1), 
            addAltitude=TRUE, ...) {
    #
    # Copyright 2001,2002 Tim Hoar, Eric Gilleland, and Doug Nychka
    #
    # This file is part of the RadioSonde library for R and related languages.
    #
    # RadioSonde is free software; you can redistribute it and/or modify
    # it under the terms of the GNU General Public License as published by
    # the Free Software Foundation; either version 2 of the License, or
    # (at your option) any later version.
    #
    # RadioSonde is distributed in the hope that it will be useful,
    # but WITHOUT ANY WARRANTY; without even the implied warranty of
    # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    # GNU General Public License for more details.
    #
    # You should have received a copy of the GNU General Public License
    # along with RadioSonde; if not, write to the Free Software
    # Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    #
    
    msg <- deparse(match.call())
    #
    # Plot the SKEW-T, log p diagram and the wind profile.
    #
    # Draw the SKEW-T, log p diagram
    # Draw background 
    # if wind barbs are to be added save some room on the left
    par( mar = mar.skewt )
    
    if( winds){
      par( plt = skewplot)
           
    }
    skewt.plt <- setupSkewt()$plt
    ##############################################################
    # --- label horizontal axis with degrees F from -20,100 by 20
    # NOTE: temperature range is "hardwired" the setup plot
    ##############################################################
    # highest pressure on plot is 1050 at bottom edge.
    degc <- ((seq(-20, 100, by = 20) - 32) * 5)/9
    axis(1, at = skewtx(degc,  skewty(1050)), labels = seq(-20, 100, by = 20) )
    mtext(side = 1, line = 2, "Temperature (F)")
    ##############################################################
    # add pressure axis     
    ##############################################################
    standardLevels <- c(  1000, 850, 700, 500, 400,
                           300, 250, 200, 150, 100)  
    ypos <- skewty(standardLevels)
    axis(2, at = ypos, labels = format(standardLevels) )
    
    ##############################################################
    # add altitude axis
    ##############################################################
    if( addAltitude & !is.null( sondeData$alt[1]) ){
      require(fields)
      y <- skewty(sondeData$press)
      altKm<- sondeData$alt/1e3
      km<- 1: round( max(altKm))
      fit<- sreg( altKm, y, lambda=1e-8)
      yKm<- predict( fit, km)
      xmin <- skewtx(-33, skewty(1050))
      axis(2, line=3, at = yKm, labels = format( km), las=2, cex=.8,
           col="grey40")
    }
    ##############################################################
    # overlay  data
    ##############################################################
    first.par <- par()
    # temperature
    skewt.lines(sondeData$temp,  sondeData$press, col = col[1], ...)
    # dew point temperture
    skewt.lines(sondeData$dewpt, sondeData$press, col = col[2], ...)
    #
    ##############################################################
    # add wind barbs if this is set
    ##############################################################
    if (winds) {
      # Draw the windplot in the "space allocated"
      par(
        new = TRUE, pty = "m", plt = windplot, err = -1.
      )
      plotwind(dataframe = sondeData, size = s, legend = FALSE)
###############################################################      
# restore the original graphics parameters so one can 
#      add to first plot. 
# THIS DOES NOT WORK !!!      
##############################################################      
      
      par(
        plt = first.par$plt,
        mar = first.par$mar,
        new = FALSE,
        pty = first.par$pty,
        usr = first.par$usr
      )
    }
    #return( first.par)
    
    invisible()
  }
